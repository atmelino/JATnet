#!/bin/bash



java -cp "../../../dist/*" jat.examples.Test


echo press enter

read input


