#!/bin/bash

java -cp ../../../dist/jatcore.jar:../../../dist/jatexamples.jar:../../../lib/plot.jar  jat.examples.IntegratorExample.SimpleIntegrator

echo press enter

read input


