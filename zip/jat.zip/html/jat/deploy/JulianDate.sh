

ls ../../../dist

#java -jar ../../../dist/jatexamplesNOSA.jar:../../../dist/jatcore.jar:../../../dist/jatcoreNOSA.jar jat.examples.JulianDate.JulianDate

#java -jar ./jatexamplesNOSA.jar jat.examples.JulianDate.JulianDate


java -cp "../../../dist/*" jat.examples.JulianDate.JulianDate
java -cp "../../../dist/*" jat.application.AttitudeSimulator.AttitudeSimulator

java -cp "../../../dist/*" jat.examples.JulianDate.DateConverterGUI



echo press enter

read input


