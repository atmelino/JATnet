

ls ../../../dist

#java -jar ../../../dist/jatexamplesNOSA.jar:../../../dist/jatcore.jar:../../../dist/jatcoreNOSA.jar jat.examples.JulianDate.JulianDate

#java -jar ./jatexamplesNOSA.jar jat.examples.JulianDate.JulianDate


#java -cp "../../../dist/*" jat.examples.JulianDate.DateConverterGUI



#works:
#java -cp "../../../dist/*" jat.application.AttitudeSimulator.AttitudeSimulator
#java -cp "../../../dist/*" jat.examples.Test
java -cp "../../../dist/*" jat.examplesNOSA.JulianDate.JulianDate



echo press enter

read input


