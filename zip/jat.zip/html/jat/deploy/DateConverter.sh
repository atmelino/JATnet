export LD_LIBRARY_PATH=/usr/lib/jni
export LD_LIBRARY_PATH=/usr/lib/jni

ECHO $LD_LIBRARY_PATH=/home/user/Desktop/j3d-1_5_2-linux-i586/lib/i386


java -cp ./jatexamples.jar jat.examples.JulianDate.DateConvertermain.class

echo press enter

read input


