#java -cp ./jatexamples.jar jat.examples.JulianDate.DateConvertermain


#works:
#java -cp "../../../dist/*" jat.examplesNOSA.JulianDate.JulianDate


java -cp "../../../dist/*:../../../lib/*" jat.examples.JulianDate.DateConvertermain

echo press enter

read input


