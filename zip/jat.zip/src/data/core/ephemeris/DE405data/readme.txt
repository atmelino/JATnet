
The DE405 data files can be found at:

ftp://ssd.jpl.nasa.gov/pub/eph/planets/

download all the files ending in *.405